<!-- Navigation -->
				<nav id="nav">
					<ul class="main-menu nav navbar-nav navbar-right">
						<li><a href="/website/public">Home</a></li>
						<li><a href="/website/public/about">About</a></li>
						<li><a href="/website/public/course">Courses</a></li>
						<li><a href="/website/public/blog">Blog</a></li>
						<li><a href="/website/public/contact">Contact</a></li>
						<li><a href="/website/public/login">Login</a></li>
					</ul>
				</nav>
				<!-- /Navigation -->

			</div>
		</header>
		<!-- /Header -->